"use strict"
// tabSwitch();
contentRendering();
// function tabSwitch(){
//     var btnActive  = document.getElementsByClassName('active-override'); //Btn control 
//     var btn = document.getElementsByClassName('btn');
//         if(btnActive[0].classList.contains('active-override')){
//             btn[0].onclick=function(){
//                 btnActive[0].style.backgroundColor="inherit";
//             };
//             btn[1].onclick=function(){
//                 btnActive[0].style.backgroundColor="inherit";  
//             };
//             btn[2].onclick=function(){
//                 btnActive[0].style.backgroundColor="inherit";
//             };
//              btn[3].onclick=function(){
//                 btnActive[0].style.backgroundColor="inherit";
//             };
//         }
// }
function contentRendering(){
    if(screen.width < 400){
        var navDisplay = document.getElementById('navigate');
        navDisplay.classList.add('nav-stacked');
        var cartIconOff = document.getElementById('cart');
        cartIconOff.style.display="none";
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="auto";
        navAlignment[0].style.marginRight="auto";
        var dropDownContent = document.getElementsByClassName('dropdown-menu');
        dropDownContent[0].style.marginLeft="25%";
        dropDownContent[1].style.marginLeft="25%";
    }
    if(screen.width >773 && screen.width <= 968){
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="25%";
        navAlignment[0].style.marginRight="25%";
    }
    if(screen.width >645 && screen.width <= 773){
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="20%";
        navAlignment[0].style.marginRight="20%";
    }
    if(screen.width >=554 && screen.width <= 644){
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="20%";
        navAlignment[0].style.marginRight="10%";
    }
    if(screen.width >=497 && screen.width <= 553){
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="12%";
        navAlignment[0].style.marginRight="10%";
    }
    if(screen.width >=400 && screen.width <= 486){
        var navAlignment = document.getElementsByClassName('site-nav');
        navAlignment[0].style.marginLeft="auto";
        navAlignment[0].style.marginRight="auto";
    }
}
